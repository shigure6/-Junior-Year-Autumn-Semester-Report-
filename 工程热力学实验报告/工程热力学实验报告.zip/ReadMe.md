
by TLZ 

template.tex 正文内容

template.bib 参考文献

picture 文件夹下是正文中用到的图片文件，注意引用路径

1) 参考了清华大学近代物理实验报告模版 https://www.overleaf.com/latex/templates/thu-emp-qing-hua-da-xue-jin-dai-wu-li-shi-yan-bao-gao-mo-ban/mbgqcryqhwqd

2) 朱老师提供的 弹簧振子实验报告-2022春-V1(完整报告示例)